import { WarriorSkin, CombatSkill, RankTier, LeaderboardEntry } from './types';

export const WARRIOR_SKINS: WarriorSkin[] = [
  {
    id: 'default',
    name: 'Crimson Reaper',
    description: 'Standard dark warrior forged in battlefield ashes. Balanced stats.',
    armorColor: '#0f172a',
    glowColor: '#dc2626',
    bulletColor: '#fbbf24',
    unlockScore: 0,
    healthMult: 1.0,
    speedMult: 1.0,
    dmgMult: 1.0
  },
  {
    id: 'void',
    name: 'Void Stalker',
    description: 'Agile shadow wraith. Faster movement speed but fragile armor.',
    armorColor: '#1e1b4b',
    glowColor: '#8b5cf6',
    bulletColor: '#c084fc',
    unlockScore: 2500,
    healthMult: 0.8,
    speedMult: 1.3,
    dmgMult: 1.05
  },
  {
    id: 'infernal',
    name: 'Infernal Titan',
    description: 'Heavy volcanic juggernaut. Massive health and bullet damage.',
    armorColor: '#451a03',
    glowColor: '#ea580c',
    bulletColor: '#f97316',
    unlockScore: 7500,
    healthMult: 1.4,
    speedMult: 0.85,
    dmgMult: 1.35
  },
  {
    id: 'cyber',
    name: 'Cyber Wraith',
    description: 'Tech-infused demonic supersoldier. High precision hellfire rounds.',
    armorColor: '#083344',
    glowColor: '#06b6d4',
    bulletColor: '#67e8f9',
    unlockScore: 15000,
    healthMult: 1.1,
    speedMult: 1.1,
    dmgMult: 1.2
  },
  {
    id: 'sovereign',
    name: 'Golden Sovereign',
    description: 'Supreme demonlord conqueror. Peak vitality, speed, and lethal firepower.',
    armorColor: '#3f2e00',
    glowColor: '#eab308',
    bulletColor: '#fef08a',
    unlockScore: 30000,
    healthMult: 1.5,
    speedMult: 1.25,
    dmgMult: 1.5
  }
];

export const COMBAT_SKILLS: CombatSkill[] = [
  {
    id: 'dash',
    name: 'Shadow Dash',
    description: 'Instant phase teleport in your movement direction. Grants 0.5s invulnerability.',
    cooldown: 4,
    duration: 0.5,
    color: '#38bdf8'
  },
  {
    id: 'nova',
    name: 'Hellfire Nova',
    description: 'Unleash a fiery radial shockwave that incinerates nearby demons and knocks them back.',
    cooldown: 8,
    color: '#f97316'
  },
  {
    id: 'turret',
    name: 'Demon Turret',
    description: 'Deploy a floating demonic skull turret that auto-targets and fires at incoming waves for 10s.',
    cooldown: 14,
    duration: 10,
    color: '#a855f7'
  },
  {
    id: 'vampire',
    name: 'Soul Feast Aura',
    description: 'Activate a dark blood ritual for 6s. Every enemy hit restores warrior vitality.',
    cooldown: 16,
    duration: 6,
    color: '#ef4444'
  }
];

export const RANK_TIERS: RankTier[] = [
  { tier: 'Grandmaster', name: 'Sovereign of Hell', minScore: 40000, color: '#eab308', badge: '👑' },
  { tier: 'Diamond', name: 'Doom Bringer', minScore: 20000, color: '#38bdf8', badge: '💎' },
  { tier: 'Platinum', name: 'Demon Slayer', minScore: 10000, color: '#a855f7', badge: '🛡️' },
  { tier: 'Gold', name: 'Soul Reaper', minScore: 5000, color: '#f59e0b', badge: '⚔️' },
  { tier: 'Silver', name: 'Fallen Warrior', minScore: 2000, color: '#94a3b8', badge: '🥈' },
  { tier: 'Bronze', name: 'Ash Wanderer', minScore: 0, color: '#b45309', badge: '🥉' }
];

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, name: 'Vortex_Slayer', score: 68450, kills: 482, wave: 28, skinId: 'sovereign' },
  { rank: 2, name: 'DOOM_Reaper99', score: 54200, kills: 395, wave: 24, skinId: 'sovereign' },
  { rank: 3, name: 'DarkK1ng_K', score: 45100, kills: 340, wave: 21, skinId: 'cyber' },
  { rank: 4, name: 'Azazel_Hell', score: 38900, kills: 290, wave: 18, skinId: 'infernal' },
  { rank: 5, name: 'ShadowByte', score: 31500, kills: 245, wave: 16, skinId: 'cyber' },
  { rank: 6, name: 'BloodRaven', score: 26400, kills: 210, wave: 14, skinId: 'void' },
  { rank: 7, name: 'SkullCrusher', score: 19800, kills: 165, wave: 12, skinId: 'infernal' },
  { rank: 8, name: 'GraveDigger_X', score: 14200, kills: 125, wave: 10, skinId: 'void' },
  { rank: 9, name: 'Kuldeep_Warrior', score: 9800, kills: 88, wave: 8, skinId: 'default' },
  { rank: 10, name: 'DemonBane77', score: 6500, kills: 60, wave: 6, skinId: 'default' },
  { rank: 11, name: 'NewbieGhost', score: 3200, kills: 32, wave: 4, skinId: 'default' },
  { rank: 12, name: 'AshWalker', score: 1100, kills: 12, wave: 2, skinId: 'default' }
];

export function getRankTier(score: number): RankTier {
  for (const tier of RANK_TIERS) {
    if (score >= tier.minScore) return tier;
  }
  return RANK_TIERS[RANK_TIERS.length - 1];
}

export function getGlobalLeaderboard(playerScore: number, playerKills: number, playerWave: number, playerName: string, skinId: string): LeaderboardEntry[] {
  const safeName = playerName.trim() || 'Dark_Warrior';
  const playerEntry: LeaderboardEntry = {
    rank: 0,
    name: safeName,
    score: playerScore,
    kills: playerKills,
    wave: playerWave,
    skinId,
    isPlayer: true
  };

  const combined = [...MOCK_LEADERBOARD, playerEntry];
  // Sort descending by score
  combined.sort((a, b) => b.score - a.score);

  // Assign ranks
  return combined.map((entry, index) => ({
    ...entry,
    rank: index + 1
  }));
}
