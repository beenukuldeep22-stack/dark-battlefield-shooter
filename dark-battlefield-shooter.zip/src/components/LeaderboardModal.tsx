import React from 'react';
import { Trophy, Skull, Flame, Crown, ShieldAlert, Sparkles, User, X } from 'lucide-react';
import { getGlobalLeaderboard, getRankTier, WARRIOR_SKINS } from '../gameData';
import { GameStats } from '../types';

interface LeaderboardModalProps {
  stats: GameStats;
  playerName: string;
  selectedSkinId: string;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  stats,
  playerName,
  selectedSkinId,
  onClose
}) => {
  const leaderboard = getGlobalLeaderboard(stats.highScore, stats.highKills, stats.wave, playerName, selectedSkinId);
  const playerRankTier = getRankTier(stats.highScore);
  const playerRankObj = leaderboard.find(e => e.isPlayer);

  return (
    <div className="absolute inset-0 bg-slate-950/95 flex items-center justify-center p-4 select-none z-50 animate-fade-in overflow-y-auto">
      <div className="max-w-3xl w-full bg-slate-900/95 border-2 border-[#D4AF37]/80 rounded-2xl p-6 md:p-8 shadow-2xl shadow-yellow-950/60 text-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-yellow-900/50 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <Trophy className="w-8 h-8 text-[#D4AF37] animate-bounce" />
            <div>
              <h2 className="text-2xl md:text-3xl font-black tracking-tighter uppercase bg-gradient-to-r from-amber-200 via-[#D4AF37] to-orange-400 bg-clip-text text-transparent">
                Global Hall of Doom
              </h2>
              <p className="text-xs text-slate-400">Competitive world rankings of top dark warriors and soul reapers.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Player Current Competitive Tier Banner */}
        <div className="w-full bg-gradient-to-r from-slate-950 via-amber-950/40 to-slate-950 border border-[#D4AF37]/60 rounded-xl p-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="text-3xl p-3 bg-slate-900 border border-amber-500/40 rounded-xl">
              {playerRankTier.badge}
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-amber-400 block font-bold">Your Rank Tier</span>
              <span className="text-xl font-black tracking-tight uppercase" style={{ color: playerRankTier.color }}>
                {playerRankTier.tier} • {playerRankTier.name}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6 bg-slate-900/80 px-5 py-2.5 rounded-xl border border-slate-800 font-mono">
            <div className="text-center">
              <span className="text-[10px] text-slate-500 uppercase block font-sans">World Rank</span>
              <span className="text-lg font-black text-[#D4AF37]">#{playerRankObj?.rank || '-'}</span>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div className="text-center">
              <span className="text-[10px] text-slate-500 uppercase block font-sans">High Score</span>
              <span className="text-lg font-black text-white">{stats.highScore.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Table Header */}
        <div className="grid grid-cols-12 px-4 py-2 bg-slate-950 text-[11px] font-bold uppercase text-slate-400 tracking-wider rounded-t-xl border-x border-t border-slate-800">
          <div className="col-span-2 sm:col-span-1 text-center">Rank</div>
          <div className="col-span-5 sm:col-span-5">Warrior</div>
          <div className="col-span-3 sm:col-span-3 text-right">Score</div>
          <div className="col-span-2 sm:col-span-3 text-right">Kills / Wave</div>
        </div>

        {/* Leaderboard Entries */}
        <div className="overflow-y-auto flex-1 border border-slate-800 rounded-b-xl divide-y divide-slate-800/80 bg-slate-950/60">
          {leaderboard.map((entry) => {
            const isTop3 = entry.rank <= 3;
            const skinObj = WARRIOR_SKINS.find(s => s.id === entry.skinId) || WARRIOR_SKINS[0];

            return (
              <div
                key={`${entry.name}-${entry.rank}`}
                className={`grid grid-cols-12 px-4 py-3 items-center text-xs transition ${
                  entry.isPlayer
                    ? 'bg-gradient-to-r from-amber-950/80 via-red-950/60 to-amber-950/80 border-l-4 border-l-amber-400 text-amber-200 font-bold'
                    : 'hover:bg-slate-900/50 text-slate-300'
                }`}
              >
                {/* Rank */}
                <div className="col-span-2 sm:col-span-1 text-center font-mono font-black">
                  {entry.rank === 1 && <Crown className="w-5 h-5 text-yellow-400 inline animate-pulse" />}
                  {entry.rank === 2 && <span className="text-slate-300">#2</span>}
                  {entry.rank === 3 && <span className="text-amber-600">#3</span>}
                  {entry.rank > 3 && <span className="text-slate-500">#{entry.rank}</span>}
                </div>

                {/* Name & Skin Badge */}
                <div className="col-span-5 sm:col-span-5 flex items-center gap-2.5 truncate pr-2">
                  <div
                    className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center border text-[10px]"
                    style={{ backgroundColor: skinObj.armorColor, borderColor: skinObj.glowColor }}
                  >
                    <Skull className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="truncate">
                    <span className="truncate block font-medium">
                      {entry.name} {entry.isPlayer && <span className="text-[10px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded ml-1 font-black">YOU</span>}
                    </span>
                    <span className="text-[10px] text-slate-500 block">{skinObj.name}</span>
                  </div>
                </div>

                {/* Score */}
                <div className="col-span-3 sm:col-span-3 text-right font-mono font-black text-amber-400 text-sm">
                  {entry.score.toLocaleString()}
                </div>

                {/* Kills & Wave */}
                <div className="col-span-2 sm:col-span-3 text-right font-mono text-slate-400">
                  <span className="text-red-400 font-bold">{entry.kills}</span> <span className="hidden sm:inline text-slate-600">/ W{entry.wave}</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
          <span>Achieve 40,000+ points to claim Sovereign of Hell rank.</span>
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl uppercase transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
