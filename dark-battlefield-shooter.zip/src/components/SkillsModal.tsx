import React from 'react';
import { Zap, Shield, Flame, Skull, Check, Sparkles, X } from 'lucide-react';
import { COMBAT_SKILLS } from '../gameData';
import { CombatSkill, SkillType } from '../types';

interface SkillsModalProps {
  selectedSkillId: SkillType;
  onSelectSkill: (skillId: SkillType) => void;
  onClose: () => void;
}

export const SkillsModal: React.FC<SkillsModalProps> = ({
  selectedSkillId,
  onSelectSkill,
  onClose
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/95 flex items-center justify-center p-4 select-none z-50 animate-fade-in overflow-y-auto">
      <div className="max-w-3xl w-full bg-slate-900/95 border-2 border-amber-600/80 rounded-2xl p-6 md:p-8 shadow-2xl shadow-amber-950/60 text-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-900/60 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <Zap className="w-7 h-7 text-amber-400 animate-pulse" />
            <div>
              <h2 className="text-2xl md:text-3xl font-black tracking-tighter uppercase bg-gradient-to-r from-amber-400 via-orange-400 to-red-500 bg-clip-text text-transparent">
                Warrior Tactical Skills
              </h2>
              <p className="text-xs text-slate-400">Equip an active combat skill triggered during battle with [SHIFT] or [E].</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto pr-1 flex-1">
          {COMBAT_SKILLS.map((skill: CombatSkill) => {
            const isSelected = selectedSkillId === skill.id;

            return (
              <div
                key={skill.id}
                onClick={() => onSelectSkill(skill.id)}
                className={`relative p-5 rounded-xl border transition-all duration-200 flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-b from-amber-950/60 to-slate-900 border-amber-400 shadow-xl shadow-amber-950/50 scale-[1.01]'
                    : 'bg-slate-950/80 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center border shadow-lg"
                        style={{ backgroundColor: `${skill.color}20`, borderColor: skill.color, boxShadow: `0 0 12px ${skill.color}30` }}
                      >
                        {skill.id === 'dash' && <Zap className="w-5 h-5" style={{ color: skill.color }} />}
                        {skill.id === 'nova' && <Flame className="w-5 h-5" style={{ color: skill.color }} />}
                        {skill.id === 'turret' && <Skull className="w-5 h-5" style={{ color: skill.color }} />}
                        {skill.id === 'vampire' && <Shield className="w-5 h-5" style={{ color: skill.color }} />}
                      </div>
                      <span className="font-black text-base tracking-wide uppercase text-slate-100">{skill.name}</span>
                    </div>

                    {isSelected && (
                      <span className="flex items-center gap-1 px-2.5 py-1 bg-amber-400 text-slate-950 font-black text-[10px] uppercase rounded-full tracking-wider">
                        <Check className="w-3 h-3 stroke-[3]" /> Equipped
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-400 mb-4 leading-relaxed">{skill.description}</p>
                </div>

                {/* Cooldown Info */}
                <div className="bg-slate-900/90 border border-slate-800/80 rounded-lg p-2.5 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-500 uppercase font-sans font-bold text-[10px]">Battle Cooldown</span>
                  <span className="text-amber-400 font-bold">{skill.cooldown} Seconds</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-8 py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-black rounded-xl uppercase tracking-wider shadow-lg cursor-pointer transition"
          >
            Confirm Skill
          </button>
        </div>
      </div>
    </div>
  );
};
