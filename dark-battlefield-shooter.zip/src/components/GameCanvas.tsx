import React, { useEffect, useRef } from 'react';
import {
  Player,
  Enemy,
  Bullet,
  PowerUp,
  Particle,
  FloatingText,
  BackgroundCrater,
  BackgroundFlame,
  GameStats,
  Position,
  EnemyType,
  Turret,
  SkillType
} from '../types';
import { WARRIOR_SKINS, COMBAT_SKILLS } from '../gameData';
import { sounds } from '../audio';

interface GameCanvasProps {
  isPlaying: boolean;
  isPaused: boolean;
  onGameOver: (finalStats: GameStats, newHighScore: boolean) => void;
  onUpdateHUD: (stats: GameStats, player: Player, bombCount: number) => void;
  bombTriggered: number;
  skillTriggered: number;
  selectedSkinId: string;
  selectedSkillId: SkillType;
  touchMoveVector: Position;
  touchAimVector: Position | null;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  isPlaying,
  isPaused,
  onGameOver,
  onUpdateHUD,
  bombTriggered,
  skillTriggered,
  selectedSkinId,
  selectedSkillId,
  touchMoveVector,
  touchAimVector
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Core Game State References
  const playerRef = useRef<Player>({
    x: 0,
    y: 0,
    radius: 18,
    angle: 0,
    health: 100,
    maxHealth: 100,
    speed: 4,
    skinId: 'default',
    skillId: 'dash',
    skillCooldownTimer: 0,
    skillActiveTimer: 0,
    activePowerUps: { rapidFireTimer: 0, shieldTimer: 0 }
  });

  const statsRef = useRef<GameStats>({
    score: 0,
    kills: 0,
    wave: 1,
    highScore: 0,
    highKills: 0
  });

  const bombCountRef = useRef<number>(1);

  const enemiesRef = useRef<Enemy[]>([]);
  const bulletsRef = useRef<Bullet[]>([]);
  const powerUpsRef = useRef<PowerUp[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const cratersRef = useRef<BackgroundCrater[]>([]);
  const flamesRef = useRef<BackgroundFlame[]>([]);
  const turretsRef = useRef<Turret[]>([]);

  // Controls & Spawner State
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const mouseRef = useRef<{ x: number; y: number; isDown: boolean }>({ x: 0, y: 0, isDown: false });
  const shootCooldownRef = useRef<number>(0);
  const waveEnemiesRemainingRef = useRef<number>(10);
  const spawnTimerRef = useRef<number>(0);
  const screenShakeRef = useRef<number>(0);
  const lastBombTriggerRef = useRef<number>(0);
  const lastSkillTriggerRef = useRef<number>(0);

  // Load High Scores on mount
  useEffect(() => {
    try {
      const savedScore = localStorage.getItem('dbs_highScore');
      const savedKills = localStorage.getItem('dbs_highKills');
      if (savedScore) statsRef.current.highScore = parseInt(savedScore, 10) || 0;
      if (savedKills) statsRef.current.highKills = parseInt(savedKills, 10) || 0;
    } catch (e) {
      console.error("Could not load high scores", e);
    }
  }, []);

  // Initialize or Reset Battlefield
  const initGame = (width: number, height: number) => {
    const skinObj = WARRIOR_SKINS.find(s => s.id === selectedSkinId) || WARRIOR_SKINS[0];
    const baseMaxHealth = Math.round(100 * skinObj.healthMult);
    const baseSpeed = 4 * skinObj.speedMult;

    playerRef.current = {
      x: width / 2,
      y: height / 2,
      radius: 18,
      angle: 0,
      health: baseMaxHealth,
      maxHealth: baseMaxHealth,
      speed: baseSpeed,
      skinId: selectedSkinId,
      skillId: selectedSkillId,
      skillCooldownTimer: 0,
      skillActiveTimer: 0,
      activePowerUps: { rapidFireTimer: 0, shieldTimer: 0 }
    };

    statsRef.current.score = 0;
    statsRef.current.kills = 0;
    statsRef.current.wave = 1;

    bombCountRef.current = 1;
    waveEnemiesRemainingRef.current = 12;
    spawnTimerRef.current = 0;
    screenShakeRef.current = 0;

    enemiesRef.current = [];
    bulletsRef.current = [];
    powerUpsRef.current = [];
    particlesRef.current = [];
    floatingTextsRef.current = [];
    turretsRef.current = [];

    // Generate background craters
    const craters: BackgroundCrater[] = [];
    for (let i = 0; i < 25; i++) {
      craters.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: 15 + Math.random() * 35,
        alpha: 0.08 + Math.random() * 0.12
      });
    }
    cratersRef.current = craters;

    // Generate background flames
    const flames: BackgroundFlame[] = [];
    for (let i = 0; i < 15; i++) {
      flames.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: 10 + Math.random() * 20,
        offset: Math.random() * Math.PI * 2,
        speed: 2 + Math.random() * 3
      });
    }
    flamesRef.current = flames;

    sounds.playWaveStart();
    onUpdateHUD({ ...statsRef.current }, { ...playerRef.current }, bombCountRef.current);
  };

  // Trigger Bomb Blast
  const triggerBombBlast = (canvasWidth: number, canvasHeight: number) => {
    if (bombCountRef.current <= 0) return;
    bombCountRef.current -= 1;
    screenShakeRef.current = 35;
    sounds.playExplosion(true);

    // Create huge blast particles
    for (let i = 0; i < 80; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 4 + Math.random() * 12;
      particlesRef.current.push({
        id: Math.random().toString(),
        x: playerRef.current.x,
        y: playerRef.current.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: 3 + Math.random() * 6,
        color: Math.random() > 0.5 ? '#f97316' : '#ef4444',
        alpha: 1,
        decay: 0.02 + Math.random() * 0.02,
        isSpark: true
      });
    }

    // Damage all enemies
    enemiesRef.current.forEach((enemy) => {
      enemy.health -= 120;
      enemy.hitFlash = 10;
      floatingTextsRef.current.push({
        id: Math.random().toString(),
        x: enemy.x,
        y: enemy.y - 15,
        text: '120 BLAST!',
        color: '#f97316',
        alpha: 1,
        vy: -1.5,
        life: 40,
        maxLife: 40
      });
    });

    onUpdateHUD({ ...statsRef.current }, { ...playerRef.current }, bombCountRef.current);
  };

  // Trigger Tactical Combat Skill
  const triggerTacticalSkill = () => {
    const player = playerRef.current;
    if (player.skillCooldownTimer > 0) return;

    const skillObj = COMBAT_SKILLS.find(s => s.id === player.skillId) || COMBAT_SKILLS[0];
    player.skillCooldownTimer = skillObj.cooldown;

    if (player.skillId === 'dash') {
      player.skillActiveTimer = skillObj.duration || 0.5;
      sounds.playPowerUp();
      screenShakeRef.current = 10;
      const dashDist = 170;
      if (canvasRef.current) {
        player.x = Math.max(30, Math.min(canvasRef.current.width - 30, player.x + Math.cos(player.angle) * dashDist));
        player.y = Math.max(30, Math.min(canvasRef.current.height - 30, player.y + Math.sin(player.angle) * dashDist));
      }
      for (let i = 0; i < 25; i++) {
        particlesRef.current.push({
          id: Math.random().toString(),
          x: player.x,
          y: player.y,
          vx: (Math.random() - 0.5) * 6,
          vy: (Math.random() - 0.5) * 6,
          radius: 2 + Math.random() * 4,
          color: '#38bdf8',
          alpha: 1,
          decay: 0.04
        });
      }
    } else if (player.skillId === 'nova') {
      sounds.playExplosion(false);
      screenShakeRef.current = 20;
      for (let i = 0; i < 24; i++) {
        const a = (i * Math.PI * 2) / 24;
        bulletsRef.current.push({
          id: Math.random().toString(),
          x: player.x,
          y: player.y,
          vx: Math.cos(a) * 14,
          vy: Math.sin(a) * 14,
          radius: 6,
          damage: 65,
          isPlayer: true,
          color: '#f97316',
          trail: []
        });
      }
    } else if (player.skillId === 'turret') {
      sounds.playPowerUp();
      turretsRef.current.push({
        id: Math.random().toString(),
        x: player.x,
        y: player.y - 40,
        radius: 14,
        life: skillObj.duration || 10,
        shootCooldown: 0,
        color: '#a855f7'
      });
      floatingTextsRef.current.push({
        id: Math.random().toString(),
        x: player.x,
        y: player.y - 30,
        text: 'SKULL TURRET DEPLOYED!',
        color: '#a855f7',
        alpha: 1,
        vy: -1.5,
        life: 45,
        maxLife: 45
      });
    } else if (player.skillId === 'vampire') {
      player.skillActiveTimer = skillObj.duration || 6;
      sounds.playPowerUp();
      floatingTextsRef.current.push({
        id: Math.random().toString(),
        x: player.x,
        y: player.y - 30,
        text: 'SOUL FEAST AURA ACTIVE!',
        color: '#ef4444',
        alpha: 1,
        vy: -1.5,
        life: 45,
        maxLife: 45
      });
    }

    onUpdateHUD({ ...statsRef.current }, { ...playerRef.current }, bombCountRef.current);
  };

  // Check external triggers
  useEffect(() => {
    if (isPlaying && !isPaused && bombTriggered > lastBombTriggerRef.current && canvasRef.current) {
      lastBombTriggerRef.current = bombTriggered;
      triggerBombBlast(canvasRef.current.width, canvasRef.current.height);
    }
  }, [bombTriggered, isPlaying, isPaused]);

  useEffect(() => {
    if (isPlaying && !isPaused && skillTriggered > lastSkillTriggerRef.current) {
      lastSkillTriggerRef.current = skillTriggered;
      triggerTacticalSkill();
    }
  }, [skillTriggered, isPlaying, isPaused]);

  // Keyboard & Mouse Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true;
      if (e.key === ' ' || e.key.toLowerCase() === 'b') {
        if (isPlaying && !isPaused && canvasRef.current) {
          triggerBombBlast(canvasRef.current.width, canvasRef.current.height);
        }
      }
      if (e.key === 'Shift' || e.key.toLowerCase() === 'e') {
        if (isPlaying && !isPaused) {
          triggerTacticalSkill();
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      mouseRef.current.x = e.clientX - rect.left;
      mouseRef.current.y = e.clientY - rect.top;
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) mouseRef.current.isDown = true;
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) mouseRef.current.isDown = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isPlaying, isPaused]);

  // Main Animation Game Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let hudUpdateTimer = 0;

    const spawnEnemy = (width: number, height: number) => {
      const wave = statsRef.current.wave;
      const side = Math.floor(Math.random() * 4);
      let x = 0;
      let y = 0;
      const margin = 50;

      if (side === 0) { x = Math.random() * width; y = -margin; }
      else if (side === 1) { x = width + margin; y = Math.random() * height; }
      else if (side === 2) { x = Math.random() * width; y = height + margin; }
      else { x = -margin; y = Math.random() * height; }

      // Determine enemy type based on wave probabilities
      const rand = Math.random();
      let type: EnemyType = 'soldier';
      let radius = 16;
      let health = 25 + wave * 5;
      let speed = 1.8 + Math.random() * 0.5 + wave * 0.1;
      let damage = 10 + wave * 2;
      let scoreValue = 100;
      let color = '#dc2626';

      if (wave >= 3 && rand < 0.25) {
        type = 'heavy_soldier';
        radius = 24;
        health = 80 + wave * 15;
        speed = 1.1 + wave * 0.05;
        damage = 25;
        scoreValue = 300;
        color = '#991b1b';
      } else if (wave >= 2 && rand >= 0.25 && rand < 0.55) {
        type = 'demon';
        radius = 18;
        health = 40 + wave * 8;
        speed = 2.0 + wave * 0.12;
        damage = 18;
        scoreValue = 200;
        color = '#ea580c';
      } else if (wave >= 4 && rand >= 0.55 && rand < 0.8) {
        type = 'fast_demon';
        radius = 14;
        health = 20 + wave * 4;
        speed = 3.2 + wave * 0.15;
        damage = 12;
        scoreValue = 250;
        color = '#f97316';
      } else if (wave >= 5 && wave % 5 === 0 && waveEnemiesRemainingRef.current === 1) {
        // Boss demon at end of every 5 waves
        type = 'boss_demon';
        radius = 38;
        health = 450 + wave * 50;
        speed = 1.2;
        damage = 40;
        scoreValue = 1500;
        color = '#7c2d12';
      }

      enemiesRef.current.push({
        id: Math.random().toString(),
        type,
        x,
        y,
        radius,
        health,
        maxHealth: health,
        speed,
        damage,
        scoreValue,
        color,
        angle: 0,
        hitFlash: 0
      });
    };

    const updateGame = (dt: number, width: number, height: number) => {
      const player = playerRef.current;
      const stats = statsRef.current;

      // Update Powerup & Skill Timers
      if (player.activePowerUps.rapidFireTimer > 0) {
        player.activePowerUps.rapidFireTimer = Math.max(0, player.activePowerUps.rapidFireTimer - dt);
      }
      if (player.activePowerUps.shieldTimer > 0) {
        player.activePowerUps.shieldTimer = Math.max(0, player.activePowerUps.shieldTimer - dt);
      }
      if (player.skillCooldownTimer > 0) {
        player.skillCooldownTimer = Math.max(0, player.skillCooldownTimer - dt);
      }
      if (player.skillActiveTimer > 0) {
        player.skillActiveTimer = Math.max(0, player.skillActiveTimer - dt);
      }

      // Update Skull Turrets AI
      turretsRef.current.forEach((t) => {
        t.life -= dt;
        t.shootCooldown -= dt;
        if (t.shootCooldown <= 0 && enemiesRef.current.length > 0) {
          t.shootCooldown = 0.35;
          let closestDist = 9999;
          let target: Enemy | null = null;
          enemiesRef.current.forEach(e => {
            const d = Math.hypot(e.x - t.x, e.y - t.y);
            if (d < closestDist && d < 420) {
              closestDist = d;
              target = e;
            }
          });
          if (target) {
            const angle = Math.atan2((target as Enemy).y - t.y, (target as Enemy).x - t.x);
            bulletsRef.current.push({
              id: Math.random().toString(),
              x: t.x,
              y: t.y,
              vx: Math.cos(angle) * 14,
              vy: Math.sin(angle) * 14,
              radius: 4,
              damage: 32,
              isPlayer: true,
              color: '#c084fc',
              trail: []
            });
          }
        }
      });
      turretsRef.current = turretsRef.current.filter(t => t.life > 0);

      // 1. Player Movement (WASD + Arrows + Virtual Stick)
      let moveX = 0;
      let moveY = 0;

      if (keysRef.current['w'] || keysRef.current['arrowup']) moveY -= 1;
      if (keysRef.current['s'] || keysRef.current['arrowdown']) moveY += 1;
      if (keysRef.current['a'] || keysRef.current['arrowleft']) moveX -= 1;
      if (keysRef.current['d'] || keysRef.current['arrowright']) moveX += 1;

      // Add touch vector
      moveX += touchMoveVector.x;
      moveY += touchMoveVector.y;

      const moveLen = Math.hypot(moveX, moveY);
      if (moveLen > 0) {
        player.x += (moveX / moveLen) * player.speed;
        player.y += (moveY / moveLen) * player.speed;
      }

      // Clamp player inside battlefield canvas
      player.x = Math.max(player.radius, Math.min(width - player.radius, player.x));
      player.y = Math.max(player.radius, Math.min(height - player.radius, player.y));

      // 2. Player Aiming
      if (touchAimVector) {
        player.angle = Math.atan2(touchAimVector.y, touchAimVector.x);
      } else {
        player.angle = Math.atan2(mouseRef.current.y - player.y, mouseRef.current.x - player.x);
      }

      // 3. Player Shooting
      shootCooldownRef.current = Math.max(0, shootCooldownRef.current - dt);
      const isShooting = mouseRef.current.isDown || touchAimVector !== null;
      const skinObj = WARRIOR_SKINS.find(s => s.id === player.skinId) || WARRIOR_SKINS[0];
      const cooldownThreshold = player.activePowerUps.rapidFireTimer > 0 ? 0.07 : 0.16;

      if (isShooting && shootCooldownRef.current <= 0) {
        shootCooldownRef.current = cooldownThreshold;
        sounds.playShoot(player.activePowerUps.rapidFireTimer > 0);

        const bulletSpeed = 16;
        const spawnX = player.x + Math.cos(player.angle) * (player.radius + 5);
        const spawnY = player.y + Math.sin(player.angle) * (player.radius + 5);

        bulletsRef.current.push({
          id: Math.random().toString(),
          x: spawnX,
          y: spawnY,
          vx: Math.cos(player.angle) * bulletSpeed,
          vy: Math.sin(player.angle) * bulletSpeed,
          radius: player.activePowerUps.rapidFireTimer > 0 ? 5 : 4,
          damage: (player.activePowerUps.rapidFireTimer > 0 ? 22 : 35) * skinObj.dmgMult,
          isPlayer: true,
          color: player.activePowerUps.rapidFireTimer > 0 ? '#fef08a' : skinObj.bulletColor,
          trail: []
        });

        // Muzzle flash particles
        for (let i = 0; i < 4; i++) {
          const sparkAngle = player.angle + (Math.random() - 0.5) * 0.6;
          const sparkSpeed = 3 + Math.random() * 5;
          particlesRef.current.push({
            id: Math.random().toString(),
            x: spawnX,
            y: spawnY,
            vx: Math.cos(sparkAngle) * sparkSpeed,
            vy: Math.sin(sparkAngle) * sparkSpeed,
            radius: 2,
            color: '#fbbf24',
            alpha: 1,
            decay: 0.08
          });
        }
      }

      // 4. Wave & Spawner Management
      if (waveEnemiesRemainingRef.current > 0) {
        spawnTimerRef.current -= dt;
        const spawnInterval = Math.max(0.2, 1.3 - stats.wave * 0.08);
        if (spawnTimerRef.current <= 0 && enemiesRef.current.length < 25 + stats.wave * 3) {
          spawnTimerRef.current = spawnInterval;
          waveEnemiesRemainingRef.current -= 1;
          spawnEnemy(width, height);
        }
      } else if (enemiesRef.current.length === 0) {
        // Wave Complete! Start Next Wave
        stats.wave += 1;
        waveEnemiesRemainingRef.current = 10 + stats.wave * 4;
        spawnTimerRef.current = 2.0; // pause brief moment
        sounds.playWaveStart();

        floatingTextsRef.current.push({
          id: Math.random().toString(),
          x: player.x,
          y: player.y - 40,
          text: `WAVE ${stats.wave} INCOMING!`,
          color: '#fbbf24',
          alpha: 1,
          vy: -1,
          life: 90,
          maxLife: 90
        });
      }

      // 5. Update Bullets
      bulletsRef.current = bulletsRef.current.filter((b) => {
        b.trail.unshift({ x: b.x, y: b.y });
        if (b.trail.length > 5) b.trail.pop();

        b.x += b.vx;
        b.y += b.vy;

        // Check bounds
        return b.x > -50 && b.x < width + 50 && b.y > -50 && b.y < height + 50;
      });

      // 6. Update Enemies & AI
      enemiesRef.current.forEach((enemy, index) => {
        if (enemy.hitFlash > 0) enemy.hitFlash -= 1;

        // Move towards player
        const dx = player.x - enemy.x;
        const dy = player.y - enemy.y;
        const dist = Math.hypot(dx, dy);

        enemy.angle = Math.atan2(dy, dx);
        if (dist > 5) {
          enemy.x += Math.cos(enemy.angle) * enemy.speed;
          enemy.y += Math.sin(enemy.angle) * enemy.speed;
        }

        // Push away from adjacent enemies (flocking separation)
        for (let j = index + 1; j < enemiesRef.current.length; j++) {
          const other = enemiesRef.current[j];
          const edx = other.x - enemy.x;
          const edy = other.y - enemy.y;
          const edist = Math.hypot(edx, edy);
          const minDist = enemy.radius + other.radius;

          if (edist < minDist && edist > 0) {
            const overlap = (minDist - edist) / 2;
            const pushX = (edx / edist) * overlap;
            const pushY = (edy / edist) * overlap;
            enemy.x -= pushX;
            enemy.y -= pushY;
            other.x += pushX;
            other.y += pushY;
          }
        }

        // Check collision with Player
        if (dist < player.radius + enemy.radius) {
          if (player.activePowerUps.shieldTimer > 0) {
            enemy.health -= 50;
            enemy.hitFlash = 5;
            sounds.playHit();
          } else if (!(player.skillId === 'dash' && player.skillActiveTimer > 0)) {
            player.health -= enemy.damage * dt * 2.5;
            screenShakeRef.current = 12;
            if (Math.random() < 0.15) sounds.playPlayerHurt();

            particlesRef.current.push({
              id: Math.random().toString(),
              x: player.x,
              y: player.y,
              vx: (Math.random() - 0.5) * 6,
              vy: (Math.random() - 0.5) * 6,
              radius: 2 + Math.random() * 3,
              color: '#dc2626',
              alpha: 1,
              decay: 0.05
            });

            if (player.health <= 0) {
              player.health = 0;
              let isNewHigh = false;
              if (stats.score > stats.highScore) {
                stats.highScore = stats.score;
                localStorage.setItem('dbs_highScore', stats.highScore.toString());
                isNewHigh = true;
              }
              if (stats.kills > stats.highKills) {
                stats.highKills = stats.kills;
                localStorage.setItem('dbs_highKills', stats.highKills.toString());
              }
              sounds.playExplosion(true);
              onGameOver({ ...stats }, isNewHigh);
            }
          }
        }
      });

      // 7. Bullet-Enemy Collision
      bulletsRef.current = bulletsRef.current.filter((bullet) => {
        let hitSomething = false;

        for (let i = 0; i < enemiesRef.current.length; i++) {
          const enemy = enemiesRef.current[i];
          const dist = Math.hypot(bullet.x - enemy.x, bullet.y - enemy.y);

          if (dist < bullet.radius + enemy.radius) {
            hitSomething = true;
            enemy.health -= bullet.damage;
            enemy.hitFlash = 6;
            sounds.playHit();

            if (bullet.isPlayer && player.skillId === 'vampire' && player.skillActiveTimer > 0) {
              player.health = Math.min(player.maxHealth, player.health + 3);
            }

            // Hit spark particles
            for (let s = 0; s < 5; s++) {
              particlesRef.current.push({
                id: Math.random().toString(),
                x: bullet.x,
                y: bullet.y,
                vx: (Math.random() - 0.5) * 8,
                vy: (Math.random() - 0.5) * 8,
                radius: 2 + Math.random() * 2,
                color: enemy.color,
                alpha: 1,
                decay: 0.05
              });
            }

            floatingTextsRef.current.push({
              id: Math.random().toString(),
              x: enemy.x + (Math.random() - 0.5) * 10,
              y: enemy.y - 10,
              text: bullet.damage.toString(),
              color: '#ffffff',
              alpha: 1,
              vy: -1.2,
              life: 30,
              maxLife: 30
            });
            break;
          }
        }

        return !hitSomething;
      });

      // 8. Handle Killed Enemies
      const aliveEnemies: Enemy[] = [];
      enemiesRef.current.forEach((enemy) => {
        if (enemy.health > 0) {
          aliveEnemies.push(enemy);
        } else {
          // Enemy Died!
          stats.kills += 1;
          stats.score += enemy.scoreValue;
          screenShakeRef.current = Math.max(screenShakeRef.current, 5);

          // Death blood explosion
          for (let p = 0; p < 15; p++) {
            const angle = Math.random() * Math.PI * 2;
            const spd = 1 + Math.random() * 6;
            particlesRef.current.push({
              id: Math.random().toString(),
              x: enemy.x,
              y: enemy.y,
              vx: Math.cos(angle) * spd,
              vy: Math.sin(angle) * spd,
              radius: 2 + Math.random() * 4,
              color: enemy.color,
              alpha: 1,
              decay: 0.03
            });
          }

          floatingTextsRef.current.push({
            id: Math.random().toString(),
            x: enemy.x,
            y: enemy.y,
            text: `+${enemy.scoreValue}`,
            color: '#fbbf24',
            alpha: 1,
            vy: -1.5,
            life: 45,
            maxLife: 45
          });

          // Chance to drop powerup (15%)
          if (Math.random() < 0.16) {
            const types: ('rapid_fire' | 'shield' | 'bomb' | 'health')[] = ['rapid_fire', 'shield', 'bomb', 'health'];
            const pType = types[Math.floor(Math.random() * types.length)];
            powerUpsRef.current.push({
              id: Math.random().toString(),
              x: enemy.x,
              y: enemy.y,
              radius: 14,
              type: pType,
              spawnTime: performance.now(),
              pulseAngle: 0
            });
          }
        }
      });
      enemiesRef.current = aliveEnemies;

      // 9. Player-PowerUp Pickup Collision
      powerUpsRef.current = powerUpsRef.current.filter((pu) => {
        pu.pulseAngle += dt * 5;
        const dist = Math.hypot(player.x - pu.x, player.y - pu.y);

        if (dist < player.radius + pu.radius + 8) {
          // Picked up!
          sounds.playPowerUp(pu.type);

          if (pu.type === 'rapid_fire') {
            player.activePowerUps.rapidFireTimer = 8;
            floatingTextsRef.current.push({
              id: Math.random().toString(),
              x: player.x,
              y: player.y - 20,
              text: 'RAPID FIRE [8s]',
              color: '#fef08a',
              alpha: 1,
              vy: -2,
              life: 50,
              maxLife: 50
            });
          } else if (pu.type === 'shield') {
            player.activePowerUps.shieldTimer = 10;
            floatingTextsRef.current.push({
              id: Math.random().toString(),
              x: player.x,
              y: player.y - 20,
              text: 'FORCE SHIELD [10s]',
              color: '#22d3ee',
              alpha: 1,
              vy: -2,
              life: 50,
              maxLife: 50
            });
          } else if (pu.type === 'bomb') {
            bombCountRef.current += 1;
            floatingTextsRef.current.push({
              id: Math.random().toString(),
              x: player.x,
              y: player.y - 20,
              text: '+1 HELL BOMB',
              color: '#ef4444',
              alpha: 1,
              vy: -2,
              life: 50,
              maxLife: 50
            });
          } else if (pu.type === 'health') {
            player.health = Math.min(player.maxHealth, player.health + 30);
            floatingTextsRef.current.push({
              id: Math.random().toString(),
              x: player.x,
              y: player.y - 20,
              text: '+30 VITALITY',
              color: '#34d399',
              alpha: 1,
              vy: -2,
              life: 50,
              maxLife: 50
            });
          }
          return false;
        }

        // Despawn powerups after 12 seconds
        return performance.now() - pu.spawnTime < 12000;
      });

      // 10. Update Particles & Floating Text
      particlesRef.current = particlesRef.current.filter((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.95;
        p.vy *= 0.95;
        p.alpha -= p.decay;
        return p.alpha > 0;
      });

      floatingTextsRef.current = floatingTextsRef.current.filter((ft) => {
        ft.y += ft.vy;
        ft.life -= 1;
        ft.alpha = ft.life / ft.maxLife;
        return ft.life > 0;
      });

      // Screen shake decay
      if (screenShakeRef.current > 0) {
        screenShakeRef.current *= 0.88;
        if (screenShakeRef.current < 0.2) screenShakeRef.current = 0;
      }
    };

    const renderGame = (ctx: CanvasRenderingContext2D, width: number, height: number, now: number) => {
      ctx.save();

      // Apply screen shake
      if (screenShakeRef.current > 0) {
        const shakeX = (Math.random() - 0.5) * screenShakeRef.current * 1.5;
        const shakeY = (Math.random() - 0.5) * screenShakeRef.current * 1.5;
        ctx.translate(shakeX, shakeY);
      }

      // 1. Dark Battlefield Background
      ctx.fillStyle = '#0a0d14'; // deep dark slate/black
      ctx.fillRect(-20, -20, width + 40, height + 40);

      // Draw ruined ground grid / textures
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      const gridSize = 60;
      ctx.beginPath();
      for (let x = 0; x < width; x += gridSize) {
        ctx.moveTo(x, 0); ctx.lineTo(x, height);
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.moveTo(0, y); ctx.lineTo(width, y);
      }
      ctx.stroke();

      // Draw background craters
      cratersRef.current.forEach((c) => {
        ctx.beginPath();
        ctx.arc(c.x, c.y, c.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(15, 23, 42, ${c.alpha * 5})`;
        ctx.fill();
        ctx.strokeStyle = `rgba(30, 41, 59, ${c.alpha * 3})`;
        ctx.stroke();
      });

      // Draw burning background fire pockets
      flamesRef.current.forEach((f) => {
        const pulse = Math.sin(now * 0.006 * f.speed + f.offset) * 3;
        const radius = Math.max(2, f.size + pulse);

        const grad = ctx.createRadialGradient(f.x, f.y, 1, f.x, f.y, radius * 2);
        grad.addColorStop(0, 'rgba(234, 88, 12, 0.4)');
        grad.addColorStop(0.5, 'rgba(185, 28, 28, 0.2)');
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(f.x, f.y, radius * 2, 0, Math.PI * 2);
        ctx.fill();
      });

      // 2. Draw PowerUps
      powerUpsRef.current.forEach((pu) => {
        ctx.save();
        ctx.translate(pu.x, pu.y);

        const pulse = Math.sin(pu.pulseAngle) * 2;
        const r = pu.radius + pulse;

        // Glow
        ctx.shadowColor = pu.type === 'rapid_fire' ? '#eab308' : pu.type === 'shield' ? '#06b6d4' : pu.type === 'bomb' ? '#ef4444' : '#10b981';
        ctx.shadowBlur = 15;

        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fillStyle = '#0f172a';
        ctx.fill();
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = ctx.shadowColor;
        ctx.stroke();

        // Icon text
        ctx.shadowBlur = 0;
        ctx.fillStyle = ctx.shadowColor;
        ctx.font = 'bold 12px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const symbol = pu.type === 'rapid_fire' ? 'â¡' : pu.type === 'shield' ? 'â«' : pu.type === 'bomb' ? 'ð£' : 'â¤';
        ctx.fillText(symbol, 0, 1);

        ctx.restore();
      });

      // 3. Draw Bullets
      bulletsRef.current.forEach((b) => {
        // Draw bullet trail
        if (b.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(b.x, b.y);
          for (let i = 0; i < b.trail.length; i++) {
            ctx.lineTo(b.trail[i].x, b.trail[i].y);
          }
          ctx.strokeStyle = b.color;
          ctx.lineWidth = b.radius;
          ctx.stroke();
        }

        ctx.shadowColor = b.color;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
        ctx.fillStyle = b.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // 4. Draw Enemies
      enemiesRef.current.forEach((enemy) => {
        ctx.save();
        ctx.translate(enemy.x, enemy.y);
        ctx.rotate(enemy.angle);

        // Shadow / Glow
        ctx.shadowColor = enemy.color;
        ctx.shadowBlur = enemy.hitFlash > 0 ? 25 : 8;

        // Body
        ctx.beginPath();
        ctx.arc(0, 0, enemy.radius, 0, Math.PI * 2);
        ctx.fillStyle = enemy.hitFlash > 0 ? '#ffffff' : '#0f172a';
        ctx.fill();
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = enemy.hitFlash > 0 ? '#ffffff' : enemy.color;
        ctx.stroke();

        ctx.shadowBlur = 0;

        // Draw demon horns or soldier visor
        if (enemy.type === 'demon' || enemy.type === 'boss_demon' || enemy.type === 'fast_demon') {
          // Glowing red/orange demon eyes
          ctx.fillStyle = '#f97316';
          ctx.beginPath();
          ctx.arc(enemy.radius * 0.4, -enemy.radius * 0.3, enemy.radius * 0.18, 0, Math.PI * 2);
          ctx.arc(enemy.radius * 0.4, enemy.radius * 0.3, enemy.radius * 0.18, 0, Math.PI * 2);
          ctx.fill();

          // Horns
          ctx.fillStyle = enemy.color;
          ctx.beginPath();
          ctx.moveTo(0, -enemy.radius);
          ctx.lineTo(-enemy.radius * 0.8, -enemy.radius * 1.5);
          ctx.lineTo(-enemy.radius * 0.4, -enemy.radius * 0.8);
          ctx.fill();

          ctx.beginPath();
          ctx.moveTo(0, enemy.radius);
          ctx.lineTo(-enemy.radius * 0.8, enemy.radius * 1.5);
          ctx.lineTo(-enemy.radius * 0.4, enemy.radius * 0.8);
          ctx.fill();
        } else {
          // Soldier visor / helmet
          ctx.fillStyle = enemy.hitFlash > 0 ? '#ffffff' : enemy.color;
          ctx.fillRect(0, -enemy.radius * 0.4, enemy.radius + 4, enemy.radius * 0.8);
        }

        ctx.restore();

        // Draw Health Bar above enemy if damaged
        if (enemy.health < enemy.maxHealth) {
          const barW = enemy.radius * 2;
          const barH = 3;
          const hpPct = Math.max(0, enemy.health / enemy.maxHealth);
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(enemy.x - barW / 2, enemy.y - enemy.radius - 10, barW, barH);
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(enemy.x - barW / 2, enemy.y - enemy.radius - 10, barW * hpPct, barH);
        }
      });

      // Draw Deployed Skull Turrets
      turretsRef.current.forEach((turret) => {
        ctx.save();
        ctx.translate(turret.x, turret.y);
        ctx.shadowColor = turret.color;
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.arc(0, 0, turret.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#1e1b4b';
        ctx.fill();
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = turret.color;
        ctx.stroke();

        // Turret skull eyes
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(-3, -3, 3, 0, Math.PI * 2);
        ctx.arc(3, -3, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // 5. Draw Player (Skull Warrior)
      const player = playerRef.current;
      const skinObjRender = WARRIOR_SKINS.find(s => s.id === player.skinId) || WARRIOR_SKINS[0];
      ctx.save();
      ctx.translate(player.x, player.y);

      // Force Shield Powerup Ring
      if (player.activePowerUps.shieldTimer > 0) {
        ctx.save();
        ctx.rotate(now * 0.004);
        ctx.shadowColor = '#22d3ee';
        ctx.shadowBlur = 20;
        ctx.beginPath();
        ctx.arc(0, 0, player.radius + 14, 0, Math.PI * 2);
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#22d3ee';
        ctx.stroke();

        // Shield energy nodes
        for (let i = 0; i < 3; i++) {
          const a = (i * Math.PI * 2) / 3;
          ctx.beginPath();
          ctx.arc(Math.cos(a) * (player.radius + 14), Math.sin(a) * (player.radius + 14), 4, 0, Math.PI * 2);
          ctx.fillStyle = '#cffafe';
          ctx.fill();
        }
        ctx.restore();
      }

      ctx.rotate(player.angle);

      // Player Dark Armor Body
      ctx.shadowColor = skinObjRender.glowColor;
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(0, 0, player.radius, 0, Math.PI * 2);
      ctx.fillStyle = skinObjRender.armorColor;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = skinObjRender.glowColor;
      ctx.stroke();

      ctx.shadowBlur = 0;

      // Gun / Weapon Arm
      ctx.fillStyle = player.activePowerUps.rapidFireTimer > 0 ? '#facc15' : '#475569';
      ctx.fillRect(player.radius - 4, -5, 16, 10);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(player.radius + 6, -3, 6, 6);

      // Menacing Skull Face
      ctx.rotate(-player.angle); // keep face oriented upward or slightly tilted
      ctx.fillStyle = '#e2e8f0'; // bone white
      ctx.beginPath();
      ctx.arc(0, -2, player.radius * 0.65, 0, Math.PI * 2);
      ctx.fill();

      // Skull Eye Sockets (Glowing Red Eyes)
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(-4, -4, 4, 0, Math.PI * 2);
      ctx.arc(4, -4, 4, 0, Math.PI * 2);
      ctx.fill();

      // Glowing Red pupils inside eye sockets
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(-4 + Math.cos(player.angle) * 1.5, -4 + Math.sin(player.angle) * 1.5, 2, 0, Math.PI * 2);
      ctx.arc(4 + Math.cos(player.angle) * 1.5, -4 + Math.sin(player.angle) * 1.5, 2, 0, Math.PI * 2);
      ctx.fill();

      // Skull Nose cavity
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.moveTo(0, -1);
      ctx.lineTo(-2, 2);
      ctx.lineTo(2, 2);
      ctx.fill();

      // Skull Teeth
      ctx.fillStyle = '#000000';
      for (let t = -4; t <= 4; t += 2.5) {
        ctx.fillRect(t - 0.5, 4, 1, 3);
      }

      ctx.restore();

      // 6. Draw Particles
      particlesRef.current.forEach((p) => {
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // 7. Draw Floating Texts
      floatingTextsRef.current.forEach((ft) => {
        ctx.save();
        ctx.globalAlpha = Math.max(0, ft.alpha);
        ctx.fillStyle = ft.color;
        ctx.font = 'black 14px sans-serif';
        ctx.textAlign = 'center';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 4;
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      });

      ctx.restore();
    };

    const loop = (currentTime: number) => {
      if (isPlaying && !isPaused && canvasRef.current) {
        const dt = Math.min(0.1, (currentTime - lastTime) / 1000);
        lastTime = currentTime;

        updateGame(dt, canvasRef.current.width, canvasRef.current.height);

        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          renderGame(ctx, canvasRef.current.width, canvasRef.current.height, currentTime);
        }

        // Periodic HUD state sync (every ~120ms to keep React UI smooth)
        hudUpdateTimer += dt;
        if (hudUpdateTimer >= 0.12) {
          hudUpdateTimer = 0;
          onUpdateHUD({ ...statsRef.current }, { ...playerRef.current }, bombCountRef.current);
        }
      } else {
        lastTime = currentTime;
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, isPaused, touchMoveVector, touchAimVector]);

  // Handle Resize
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current && canvasRef.current.parentElement) {
        canvasRef.current.width = canvasRef.current.parentElement.clientWidth;
        canvasRef.current.height = canvasRef.current.parentElement.clientHeight;
        if (isPlaying) {
          // re-clamp player
          playerRef.current.x = Math.min(canvasRef.current.width - 20, playerRef.current.x);
          playerRef.current.y = Math.min(canvasRef.current.height - 20, playerRef.current.y);
        }
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isPlaying]);

  // Start initial game when enters playing state
  useEffect(() => {
    if (isPlaying && canvasRef.current && canvasRef.current.parentElement) {
      canvasRef.current.width = canvasRef.current.parentElement.clientWidth;
      canvasRef.current.height = canvasRef.current.parentElement.clientHeight;
      initGame(canvasRef.current.width, canvasRef.current.height);
    }
  }, [isPlaying]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 block w-full h-full cursor-crosshair bg-[#0a0d14]"
      onContextMenu={(e) => e.preventDefault()}
    />
  );
};
