import React, { useState, useRef } from 'react';
import { Crosshair } from 'lucide-react';
import { Position } from '../types';

interface VirtualControlsProps {
  onMove: (vector: Position) => void;
  onAimShoot: (vector: Position | null) => void;
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({ onMove, onAimShoot }) => {
  const [leftActive, setLeftActive] = useState(false);
  const [leftPos, setLeftPos] = useState<Position>({ x: 0, y: 0 });

  const [rightActive, setRightActive] = useState(false);
  const [rightPos, setRightPos] = useState<Position>({ x: 0, y: 0 });

  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);

  const maxRadius = 45;

  const handleTouchStart = (e: React.TouchEvent, side: 'left' | 'right') => {
    e.stopPropagation();
    const touch = e.changedTouches[0];
    const ref = side === 'left' ? leftRef : rightRef;
    if (!ref.current) return;

    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = touch.clientX - centerX;
    const dy = touch.clientY - centerY;
    const dist = Math.hypot(dx, dy);

    let x = dx;
    let y = dy;
    if (dist > maxRadius) {
      x = (dx / dist) * maxRadius;
      y = (dy / dist) * maxRadius;
    }

    if (side === 'left') {
      setLeftActive(true);
      setLeftPos({ x, y });
      onMove({ x: x / maxRadius, y: y / maxRadius });
    } else {
      setRightActive(true);
      setRightPos({ x, y });
      onAimShoot({ x: x / maxRadius, y: y / maxRadius });
    }
  };

  const handleTouchMove = (e: React.TouchEvent, side: 'left' | 'right') => {
    e.stopPropagation();
    const ref = side === 'left' ? leftRef : rightRef;
    if (!ref.current) return;

    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    // Find the touch associated with this element
    for (let i = 0; i < e.touches.length; i++) {
      const touch = e.touches[i];
      const dx = touch.clientX - centerX;
      const dy = touch.clientY - centerY;
      const dist = Math.hypot(dx, dy);

      // Only process touches near this stick
      if (dist < 150) {
        let x = dx;
        let y = dy;
        if (dist > maxRadius) {
          x = (dx / dist) * maxRadius;
          y = (dy / dist) * maxRadius;
        }

        if (side === 'left') {
          setLeftPos({ x, y });
          onMove({ x: x / maxRadius, y: y / maxRadius });
        } else {
          setRightPos({ x, y });
          onAimShoot({ x: x / maxRadius, y: y / maxRadius });
        }
        break;
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent, side: 'left' | 'right') => {
    e.stopPropagation();
    if (side === 'left') {
      setLeftActive(false);
      setLeftPos({ x: 0, y: 0 });
      onMove({ x: 0, y: 0 });
    } else {
      setRightActive(false);
      setRightPos({ x: 0, y: 0 });
      onAimShoot(null);
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex justify-between items-end p-8 pb-16 md:pb-8 select-none z-20 md:hidden">
      {/* Left Joystick: Movement */}
      <div
        ref={leftRef}
        onTouchStart={(e) => handleTouchStart(e, 'left')}
        onTouchMove={(e) => handleTouchMove(e, 'left')}
        onTouchEnd={(e) => handleTouchEnd(e, 'left')}
        className="w-28 h-28 rounded-full border-2 border-slate-700/60 bg-slate-900/40 pointer-events-auto flex items-center justify-center backdrop-blur-sm shadow-xl"
      >
        <div
          className={`w-12 h-12 rounded-full border border-orange-500/80 bg-gradient-to-br from-orange-600/80 to-red-800/80 shadow-lg transition-transform ${
            !leftActive ? 'duration-150' : 'duration-0'
          }`}
          style={{ transform: `translate(${leftPos.x}px, ${leftPos.y}px)` }}
        />
      </div>

      {/* Right Joystick: Aim & Shoot */}
      <div
        ref={rightRef}
        onTouchStart={(e) => handleTouchStart(e, 'right')}
        onTouchMove={(e) => handleTouchMove(e, 'right')}
        onTouchEnd={(e) => handleTouchEnd(e, 'right')}
        className="w-28 h-28 rounded-full border-2 border-red-700/60 bg-red-950/40 pointer-events-auto flex items-center justify-center backdrop-blur-sm shadow-xl"
      >
        <div
          className={`w-14 h-14 rounded-full border border-amber-400 bg-gradient-to-br from-red-600 via-orange-500 to-amber-500 shadow-lg flex items-center justify-center transition-transform ${
            !rightActive ? 'duration-150' : 'duration-0'
          }`}
          style={{ transform: `translate(${rightPos.x}px, ${rightPos.y}px)` }}
        >
          <Crosshair className="w-6 h-6 text-white animate-spin" />
        </div>
      </div>
    </div>
  );
};
