import React from 'react';
import { Skull, Shield, Zap, Bomb, Trophy, Flame, Play, Sparkles, User, Crown } from 'lucide-react';
import { GameStats } from '../types';
import { getRankTier, WARRIOR_SKINS, COMBAT_SKILLS } from '../gameData';

interface StartMenuProps {
  stats: GameStats;
  playerName: string;
  onChangePlayerName: (name: string) => void;
  selectedSkinId: string;
  selectedSkillId: string;
  onOpenSkins: () => void;
  onOpenSkills: () => void;
  onOpenLeaderboard: () => void;
  onStart: () => void;
}

export const StartMenu: React.FC<StartMenuProps> = ({
  stats,
  playerName,
  onChangePlayerName,
  selectedSkinId,
  selectedSkillId,
  onOpenSkins,
  onOpenSkills,
  onOpenLeaderboard,
  onStart
}) => {
  const rankTier = getRankTier(stats.highScore);
  const curSkin = WARRIOR_SKINS.find(s => s.id === selectedSkinId) || WARRIOR_SKINS[0];
  const curSkill = COMBAT_SKILLS.find(s => s.id === selectedSkillId) || COMBAT_SKILLS[0];

  return (
    <div className="absolute inset-0 bg-slate-950/95 flex items-center justify-center p-4 select-none z-30 overflow-y-auto">
      {/* Background ambient glow effect */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-80 h-80 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-xl w-full bg-slate-900/90 border border-red-900/80 rounded-2xl p-6 md:p-8 shadow-2xl shadow-red-950/80 backdrop-blur-xl relative z-10 text-slate-100 flex flex-col items-center">
        {/* Header Icon */}
        <div className="relative mb-3">
          <div className="absolute -inset-2 bg-gradient-to-r from-red-600 to-orange-500 rounded-full blur opacity-75 animate-pulse" />
          <div className="relative bg-slate-950 p-4 rounded-full border border-red-500/50">
            <Skull className="w-10 h-10 text-red-500 animate-pulse" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl md:text-5xl font-black tracking-tighter text-center uppercase bg-gradient-to-r from-red-500 via-orange-400 to-amber-300 bg-clip-text text-transparent mb-1">
          Dark Battlefield
        </h1>
        <p className="text-xs text-slate-400 text-center max-w-md mb-5 font-medium">
          Survive endless demonic incursions. Reap souls and climb global rankings.
        </p>

        {/* Player Name Input & Rank Badge */}
        <div className="w-full bg-slate-950/90 border border-amber-600/50 rounded-xl p-3 mb-5 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2.5 flex-1">
            <div className="text-2xl p-1.5 bg-slate-900 rounded-lg border border-amber-500/30">
              {rankTier.badge}
            </div>
            <div className="flex-1">
              <span className="text-[10px] uppercase font-mono tracking-wider text-amber-500 block font-bold">
                {rankTier.tier} Slayer
              </span>
              <input
                type="text"
                value={playerName}
                onChange={(e) => onChangePlayerName(e.target.value)}
                placeholder="Warrior Name..."
                maxLength={16}
                className="w-full bg-transparent text-sm font-black text-white focus:outline-none tracking-wide border-b border-slate-800 focus:border-amber-400 pb-0.5 transition"
              />
            </div>
          </div>

          <button
            onClick={onOpenLeaderboard}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-amber-600/30 to-yellow-600/30 hover:from-amber-600/50 hover:to-yellow-600/50 border border-[#D4AF37] rounded-lg text-[#D4AF37] font-black text-xs uppercase tracking-wider transition cursor-pointer shadow-md"
          >
            <Trophy className="w-4 h-4 animate-bounce" />
            Rankings
          </button>
        </div>

        {/* High Score Badge */}
        <div className="grid grid-cols-2 gap-3 w-full mb-5">
          <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl flex items-center gap-3">
            <Trophy className="w-5 h-5 text-[#D4AF37]" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Best Score</span>
              <span className="text-sm font-black font-mono text-[#D4AF37]">{stats.highScore.toLocaleString()}</span>
            </div>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl flex items-center gap-3">
            <Skull className="w-5 h-5 text-red-500" />
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Highest Kills</span>
              <span className="text-sm font-black font-mono text-red-400">{stats.highKills}</span>
            </div>
          </div>
        </div>

        {/* Armory & Skills Loadout Selector Buttons */}
        <div className="grid grid-cols-2 gap-3 w-full mb-6">
          {/* Skins */}
          <button
            onClick={onOpenSkins}
            className="bg-slate-950/90 hover:bg-slate-900 border border-red-800/80 hover:border-orange-500 p-3 rounded-xl flex items-center justify-between text-left transition cursor-pointer group shadow-lg"
          >
            <div className="flex items-center gap-2.5">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center border"
                style={{ backgroundColor: curSkin.armorColor, borderColor: curSkin.glowColor }}
              >
                <Skull className="w-4 h-4 text-white" />
              </div>
              <div className="truncate">
                <span className="text-[10px] text-slate-400 uppercase block font-bold">Combat Suit</span>
                <span className="text-xs font-black text-slate-100 group-hover:text-orange-400 truncate block transition">
                  {curSkin.name}
                </span>
              </div>
            </div>
            <Sparkles className="w-4 h-4 text-orange-400 flex-shrink-0" />
          </button>

          {/* Skills */}
          <button
            onClick={onOpenSkills}
            className="bg-slate-950/90 hover:bg-slate-900 border border-amber-700/80 hover:border-amber-400 p-3 rounded-xl flex items-center justify-between text-left transition cursor-pointer group shadow-lg"
          >
            <div className="flex items-center gap-2.5">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center border bg-amber-950/40"
                style={{ borderColor: curSkill.color }}
              >
                <Zap className="w-4 h-4" style={{ color: curSkill.color }} />
              </div>
              <div className="truncate">
                <span className="text-[10px] text-slate-400 uppercase block font-bold">Tactical Skill</span>
                <span className="text-xs font-black text-slate-100 group-hover:text-amber-400 truncate block transition">
                  {curSkill.name}
                </span>
              </div>
            </div>
            <Zap className="w-4 h-4 text-amber-400 flex-shrink-0" />
          </button>
        </div>

        {/* CTA Button */}
        <button
          onClick={onStart}
          className="w-full py-4 bg-gradient-to-r from-[#C86B4A] via-red-600 to-orange-600 hover:from-[#b55c3c] hover:to-orange-500 text-white font-black text-lg tracking-wider rounded-xl uppercase shadow-xl shadow-red-900/40 transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-3 border border-orange-400/50 cursor-pointer"
        >
          <Play className="w-6 h-6 fill-white" />
          Enter Battlefield
        </button>
      </div>
    </div>
  );
};

