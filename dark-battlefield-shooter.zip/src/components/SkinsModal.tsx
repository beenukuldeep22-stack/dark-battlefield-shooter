import { Skull, Shield, Zap, Lock, Check, Sparkles, X } from 'lucide-react';
import { WARRIOR_SKINS } from '../gameData';
import { WarriorSkin } from '../types';

interface SkinsModalProps {
  currentScore: number;
  selectedSkinId: string;
  onSelectSkin: (skinId: string) => void;
  onClose: () => void;
}

export const SkinsModal: React.FC<SkinsModalProps> = ({
  currentScore,
  selectedSkinId,
  onSelectSkin,
  onClose
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/95 flex items-center justify-center p-4 select-none z-50 animate-fade-in overflow-y-auto">
      <div className="max-w-3xl w-full bg-slate-900/95 border-2 border-red-900/80 rounded-2xl p-6 md:p-8 shadow-2xl shadow-red-950/80 text-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-red-900/60 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <Sparkles className="w-7 h-7 text-amber-400 animate-pulse" />
            <div>
              <h2 className="text-2xl md:text-3xl font-black tracking-tighter uppercase bg-gradient-to-r from-red-500 via-orange-400 to-amber-300 bg-clip-text text-transparent">
                Warrior Armory Skins
              </h2>
              <p className="text-xs text-slate-400">Unlock demonic combat suits by achieving higher scores on the battlefield.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Skins Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto pr-1 flex-1">
          {WARRIOR_SKINS.map((skin: WarriorSkin) => {
            const isUnlocked = currentScore >= skin.unlockScore;
            const isSelected = selectedSkinId === skin.id;

            return (
              <div
                key={skin.id}
                onClick={() => isUnlocked && onSelectSkin(skin.id)}
                className={`relative p-4 rounded-xl border transition-all duration-200 flex flex-col justify-between ${
                  isSelected
                    ? 'bg-gradient-to-b from-red-950/80 to-slate-900 border-orange-500 shadow-xl shadow-orange-950/50 scale-[1.01]'
                    : isUnlocked
                    ? 'bg-slate-950/80 border-slate-800 hover:border-slate-700 cursor-pointer hover:bg-slate-900/60'
                    : 'bg-slate-950/40 border-slate-900 opacity-60 cursor-not-allowed'
                }`}
              >
                <div>
                  {/* Top row: Icon & Status badge */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center border-2 shadow-lg"
                        style={{ backgroundColor: skin.armorColor, borderColor: skin.glowColor, boxShadow: `0 0 12px ${skin.glowColor}40` }}
                      >
                        <Skull className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-black text-base tracking-wide uppercase text-slate-100">{skin.name}</span>
                    </div>

                    {isSelected && (
                      <span className="flex items-center gap-1 px-2.5 py-1 bg-amber-500 text-slate-950 font-black text-[10px] uppercase rounded-full tracking-wider">
                        <Check className="w-3 h-3 stroke-[3]" /> Equipped
                      </span>
                    )}
                    {!isSelected && isUnlocked && (
                      <span className="text-[10px] font-bold text-emerald-400 uppercase bg-emerald-950/80 border border-emerald-800 px-2 py-0.5 rounded">
                        Unlocked
                      </span>
                    )}
                    {!isUnlocked && (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-amber-500 uppercase bg-amber-950/80 border border-amber-800 px-2 py-0.5 rounded">
                        <Lock className="w-3 h-3" /> {skin.unlockScore.toLocaleString()} PTS
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-400 mb-4 leading-relaxed">{skin.description}</p>
                </div>

                {/* Stats Multipliers */}
                <div className="bg-slate-900/90 border border-slate-800/80 rounded-lg p-2.5 grid grid-cols-3 gap-2 text-center text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-sans font-bold">Vitality</span>
                    <span className={skin.healthMult >= 1 ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                      {Math.round(skin.healthMult * 100)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-sans font-bold">Speed</span>
                    <span className={skin.speedMult >= 1 ? 'text-cyan-400 font-bold' : 'text-amber-400 font-bold'}>
                      {Math.round(skin.speedMult * 100)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-sans font-bold">Firepower</span>
                    <span className={skin.dmgMult >= 1 ? 'text-orange-400 font-bold' : 'text-slate-400 font-bold'}>
                      {Math.round(skin.dmgMult * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-8 py-3 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-black rounded-xl uppercase tracking-wider shadow-lg cursor-pointer transition"
          >
            Return to Camp
          </button>
        </div>
      </div>
    </div>
  );
};
