import React from 'react';
import { Skull, Shield, Zap, Bomb, Volume2, VolumeX, Heart, Pause, Play, Crosshair, Flame } from 'lucide-react';
import { Player, GameStats } from '../types';
import { COMBAT_SKILLS } from '../gameData';

interface HUDProps {
  stats: GameStats;
  player: Player;
  bombCount: number;
  onUseBomb: () => void;
  onUseSkill: () => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  isPaused: boolean;
  onTogglePause: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  player,
  bombCount,
  onUseBomb,
  onUseSkill,
  audioEnabled,
  onToggleAudio,
  isPaused,
  onTogglePause
}) => {
  const healthPercent = Math.max(0, Math.min(100, (player.health / player.maxHealth) * 100));
  const curSkill = COMBAT_SKILLS.find(s => s.id === player.skillId) || COMBAT_SKILLS[0];
  const isSkillReady = player.skillCooldownTimer <= 0;

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 md:p-6 select-none font-sans">
      {/* Top Bar */}
      <div className="flex items-start justify-between gap-4">
        {/* Left: Health & Powerups */}
        <div className="flex flex-col gap-3 max-w-xs w-full pointer-events-auto">
          {/* Health Bar */}
          <div className="bg-slate-900/90 border border-red-900/60 p-2 rounded-lg shadow-xl shadow-red-950/40 backdrop-blur-md">
            <div className="flex items-center justify-between mb-1 text-xs font-bold tracking-wider text-red-200 uppercase">
              <span className="flex items-center gap-1.5 text-red-400">
                <Skull className="w-4 h-4 animate-pulse text-red-500" />
                Dark Warrior Vitality
              </span>
              <span>{Math.ceil(player.health)} / {player.maxHealth}</span>
            </div>
            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-red-950 p-0.5">
              <div
                className="h-full bg-gradient-to-r from-red-800 via-red-600 to-orange-500 rounded-full transition-all duration-200"
                style={{ width: `${healthPercent}%` }}
              />
            </div>
          </div>

          {/* Active Powerups & Skill status */}
          <div className="flex flex-wrap gap-2">
            {player.activePowerUps.rapidFireTimer > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-950/80 border border-amber-600/60 rounded text-amber-300 text-xs font-bold animate-pulse shadow-lg">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>RAPID FIRE: {Math.ceil(player.activePowerUps.rapidFireTimer)}s</span>
              </div>
            )}
            {player.activePowerUps.shieldTimer > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-cyan-950/80 border border-cyan-500/60 rounded text-cyan-300 text-xs font-bold animate-pulse shadow-lg">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span>SHIELD: {Math.ceil(player.activePowerUps.shieldTimer)}s</span>
              </div>
            )}
            {player.skillActiveTimer > 0 && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-purple-950/80 border border-purple-500/60 rounded text-purple-200 text-xs font-bold animate-pulse shadow-lg">
                <Flame className="w-3.5 h-3.5 text-purple-400" />
                <span>SKILL ACTIVE: {Math.ceil(player.skillActiveTimer)}s</span>
              </div>
            )}
          </div>
        </div>

        {/* Center: Wave & Action Notice */}
        <div className="flex flex-col items-center">
          <div className="bg-gradient-to-b from-slate-900/95 to-slate-950/90 px-6 py-2 rounded-xl border border-amber-600/50 shadow-2xl shadow-orange-950/60 backdrop-blur-md text-center">
            <span className="text-[10px] font-mono tracking-widest text-amber-500/90 uppercase block">
              Demonic Incursion
            </span>
            <span className="text-2xl md:text-3xl font-black tracking-tighter bg-gradient-to-r from-amber-200 via-orange-400 to-red-500 bg-clip-text text-transparent">
              WAVE {stats.wave}
            </span>
          </div>
        </div>

        {/* Right: Score & Kills & Controls */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl shadow-xl backdrop-blur-md min-w-[160px] flex flex-col gap-2">
            {/* Kills */}
            <div className="flex items-center justify-between gap-4 border-b border-slate-800 pb-1.5">
              <span className="text-xs font-bold text-slate-400 uppercase flex items-center gap-1.5">
                <Skull className="w-4 h-4 text-red-500" />
                Kills
              </span>
              <span className="text-lg font-black font-mono text-red-400 tracking-tight">
                {stats.kills}
              </span>
            </div>

            {/* Score */}
            <div className="flex items-center justify-between gap-4">
              <span className="text-xs font-bold text-slate-400 uppercase">Score</span>
              <span className="text-lg font-black font-mono text-amber-400 tracking-tight">
                {stats.score.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Action buttons (Audio & Pause) */}
          <div className="flex items-center gap-2">
            <button
              onClick={onTogglePause}
              className="p-2.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition shadow-lg"
              title={isPaused ? "Resume Game" : "Pause Game"}
            >
              {isPaused ? <Play className="w-4 h-4 text-amber-400" /> : <Pause className="w-4 h-4" />}
            </button>
            <button
              onClick={onToggleAudio}
              className="p-2.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition shadow-lg"
              title={audioEnabled ? "Mute Sound" : "Enable Sound"}
            >
              {audioEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-red-400" />}
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Bar: Bomb & Skill Trigger */}
      <div className="flex items-end justify-between gap-4 mt-auto">
        {/* Control Hints */}
        <div className="hidden sm:flex flex-col bg-slate-950/80 border border-slate-800/80 px-3 py-2 rounded-lg text-[11px] text-slate-400 backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-200">WASD / ARROWS</span>
            <span>Move Warrior</span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-200">MOUSE / CLICK</span>
            <span>Aim & Shoot</span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-200">SHIFT / E</span>
            <span>Tactical Skill</span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="font-mono bg-slate-800 px-1.5 py-0.5 rounded text-slate-200">SPACE / B</span>
            <span>Detonate Bomb</span>
          </div>
        </div>

        {/* Action Buttons Container */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-3 mx-auto sm:mx-0">
          {/* Tactical Skill Trigger Button */}
          <button
            onClick={onUseSkill}
            disabled={!isSkillReady}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-black tracking-wider uppercase transition-all duration-200 shadow-xl border ${
              isSkillReady
                ? 'bg-gradient-to-r from-amber-600 via-orange-500 to-red-600 hover:from-amber-500 hover:to-red-500 text-white border-amber-400 scale-100 active:scale-95 cursor-pointer shadow-amber-900/40'
                : 'bg-slate-900/80 text-slate-500 border-slate-800 shadow-none cursor-not-allowed'
            }`}
          >
            <Zap className={`w-5 h-5 ${isSkillReady ? 'animate-pulse text-yellow-300' : 'text-slate-600'}`} />
            <div className="flex flex-col text-left leading-tight">
              <span className="text-xs">{curSkill.name} [SHIFT]</span>
              <span className="text-[10px] font-mono" style={{ color: isSkillReady ? '#fef08a' : '#94a3b8' }}>
                {isSkillReady ? 'READY TO USE' : `CD: ${Math.ceil(player.skillCooldownTimer)}s`}
              </span>
            </div>
          </button>

          {/* Bomb Detonation Button */}
          <button
            onClick={onUseBomb}
            disabled={bombCount <= 0}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl font-black tracking-wider uppercase transition-all duration-200 shadow-xl border ${
              bombCount > 0
                ? 'bg-gradient-to-r from-red-600 via-orange-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white border-orange-400 shadow-orange-900/60 scale-100 active:scale-95 animate-bounce cursor-pointer'
                : 'bg-slate-900/60 text-slate-600 border-slate-800/50 shadow-none cursor-not-allowed'
            }`}
          >
            <Bomb className={`w-5 h-5 ${bombCount > 0 ? 'animate-pulse text-yellow-300' : 'text-slate-600'}`} />
            <div className="flex flex-col text-left leading-tight">
              <span className="text-xs">Detonate Bomb [SPACE]</span>
              <span className="text-[10px] text-orange-200 font-mono">AVAILABLE: {bombCount}</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

