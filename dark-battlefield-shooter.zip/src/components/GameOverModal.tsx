import React from 'react';
import { Skull, RotateCcw, Trophy, Flame, ShieldAlert } from 'lucide-react';
import { GameStats } from '../types';

interface GameOverModalProps {
  stats: GameStats;
  isNewHighScore: boolean;
  onRestart: () => void;
  onMenu: () => void;
  onLeaderboard?: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  isNewHighScore,
  onRestart,
  onMenu,
  onLeaderboard
}) => {
  return (
    <div className="absolute inset-0 bg-slate-950/95 flex items-center justify-center p-4 select-none z-40 animate-fade-in overflow-y-auto">
      {/* Background blood splatter / fire glow */}
      <div className="absolute w-[500px] h-[500px] bg-red-900/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-md w-full bg-slate-900/95 border-2 border-red-600/80 rounded-2xl p-6 md:p-8 shadow-2xl shadow-red-950 text-slate-100 flex flex-col items-center relative z-10">
        <div className="bg-red-950/80 p-4 rounded-full border border-red-500 mb-4 animate-bounce">
          <Skull className="w-12 h-12 text-red-500" />
        </div>

        <h2 className="text-4xl font-black tracking-tighter text-red-500 uppercase mb-1">
          Warrior Fallen
        </h2>
        <p className="text-xs text-slate-400 mb-6 text-center">
          The demonic swarm overwhelmed your defenses. Your skull rests among the ashes.
        </p>

        {isNewHighScore && (
          <div className="w-full bg-gradient-to-r from-amber-500/20 via-yellow-500/30 to-amber-500/20 border border-[#D4AF37] px-4 py-2 rounded-xl mb-6 flex items-center justify-center gap-2 text-[#D4AF37] font-black tracking-wide uppercase animate-pulse">
            <Trophy className="w-5 h-5" />
            <span>New Battlefield Record!</span>
          </div>
        )}

        {/* Stats Summary Card */}
        <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 mb-6">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <span className="text-xs font-bold text-slate-400 uppercase flex items-center gap-1.5">
              <Skull className="w-4 h-4 text-red-500" />
              Total Kills
            </span>
            <span className="text-xl font-black font-mono text-red-400">
              {stats.kills}
            </span>
          </div>

          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
            <span className="text-xs font-bold text-slate-400 uppercase flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-orange-400" />
              Final Score
            </span>
            <span className="text-xl font-black font-mono text-amber-400">
              {stats.score.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-purple-400" />
              Wave Reached
            </span>
            <span className="text-xl font-black font-mono text-slate-200">
              {stats.wave}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 w-full">
          <button
            onClick={onRestart}
            className="flex-1 py-3.5 bg-gradient-to-r from-[#C86B4A] to-red-600 hover:from-[#b55c3c] hover:to-red-500 text-white font-black tracking-wider rounded-xl uppercase shadow-lg transition flex items-center justify-center gap-2 border border-orange-400/40 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" />
            Respawn Now
          </button>
          {onLeaderboard && (
            <button
              onClick={onLeaderboard}
              className="py-3.5 px-4 bg-amber-600/20 hover:bg-amber-600/30 border border-[#D4AF37] text-[#D4AF37] font-bold tracking-wide rounded-xl uppercase transition cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Trophy className="w-4 h-4" />
              Rankings
            </button>
          )}
          <button
            onClick={onMenu}
            className="py-3.5 px-5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-bold tracking-wide rounded-xl uppercase transition cursor-pointer"
          >
            Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
