/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameState, GameStats, Player, Position, SkillType } from './types';
import { StartMenu } from './components/StartMenu';
import { GameOverModal } from './components/GameOverModal';
import { HUD } from './components/HUD';
import { VirtualControls } from './components/VirtualControls';
import { GameCanvas } from './components/GameCanvas';
import { SkinsModal } from './components/SkinsModal';
import { SkillsModal } from './components/SkillsModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { sounds } from './audio';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('menu');
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);
  const [bombTriggered, setBombTriggered] = useState<number>(0);
  const [skillTriggered, setSkillTriggered] = useState<number>(0);

  // Loadouts & Competitive Profile
  const [playerName, setPlayerName] = useState<string>('Vortex_Slayer');
  const [selectedSkinId, setSelectedSkinId] = useState<string>('default');
  const [selectedSkillId, setSelectedSkillId] = useState<SkillType>('dash');
  const [modalState, setModalState] = useState<'none' | 'skins' | 'skills' | 'leaderboard'>('none');

  useEffect(() => {
    const savedName = localStorage.getItem('dbs_playerName');
    const savedSkin = localStorage.getItem('dbs_skinId');
    const savedSkill = localStorage.getItem('dbs_skillId') as SkillType;
    if (savedName) setPlayerName(savedName);
    if (savedSkin) setSelectedSkinId(savedSkin);
    if (savedSkill) setSelectedSkillId(savedSkill);
  }, []);

  const handleNameChange = (name: string) => {
    setPlayerName(name);
    localStorage.setItem('dbs_playerName', name);
  };

  // Stats & HUD State Sync
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    kills: 0,
    wave: 1,
    highScore: 0,
    highKills: 0
  });

  const [player, setPlayer] = useState<Player>({
    x: 0,
    y: 0,
    radius: 18,
    angle: 0,
    health: 100,
    maxHealth: 100,
    speed: 4,
    skinId: 'default',
    skillId: 'dash',
    skillCooldownTimer: 0,
    skillActiveTimer: 0,
    activePowerUps: { rapidFireTimer: 0, shieldTimer: 0 }
  });

  const [bombCount, setBombCount] = useState<number>(1);
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);

  // Virtual Controls State for Mobile
  const [touchMoveVector, setTouchMoveVector] = useState<Position>({ x: 0, y: 0 });
  const [touchAimVector, setTouchAimVector] = useState<Position | null>(null);

  const handleStartGame = () => {
    setIsNewHighScore(false);
    setIsPaused(false);
    setGameState('playing');
  };

  const handleGameOver = (finalStats: GameStats, newHigh: boolean) => {
    setStats(finalStats);
    setIsNewHighScore(newHigh);
    setGameState('gameover');
  };

  const handleUpdateHUD = (newStats: GameStats, newPlayer: Player, newBombCount: number) => {
    setStats(newStats);
    setPlayer(newPlayer);
    setBombCount(newBombCount);
  };

  const handleUseBomb = () => {
    if (bombCount > 0 && gameState === 'playing' && !isPaused) {
      setBombTriggered(prev => prev + 1);
    }
  };

  const handleUseSkill = () => {
    if (gameState === 'playing' && !isPaused) {
      setSkillTriggered(prev => prev + 1);
    }
  };

  const handleToggleAudio = () => {
    sounds.enabled = !audioEnabled;
    setAudioEnabled(!audioEnabled);
  };

  const handleTogglePause = () => {
    setIsPaused(!isPaused);
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#0a0d14] font-sans select-none">
      {/* 1. Core Battlefield Canvas */}
      {(gameState === 'playing' || gameState === 'gameover') && (
        <GameCanvas
          isPlaying={gameState === 'playing'}
          isPaused={isPaused}
          onGameOver={handleGameOver}
          onUpdateHUD={handleUpdateHUD}
          bombTriggered={bombTriggered}
          skillTriggered={skillTriggered}
          selectedSkinId={selectedSkinId}
          selectedSkillId={selectedSkillId}
          touchMoveVector={touchMoveVector}
          touchAimVector={touchAimVector}
        />
      )}

      {/* 2. HUD Overlay */}
      {gameState === 'playing' && (
        <HUD
          stats={stats}
          player={player}
          bombCount={bombCount}
          onUseBomb={handleUseBomb}
          onUseSkill={handleUseSkill}
          audioEnabled={audioEnabled}
          onToggleAudio={handleToggleAudio}
          isPaused={isPaused}
          onTogglePause={handleTogglePause}
        />
      )}

      {/* 3. Mobile Touch Joysticks */}
      {gameState === 'playing' && !isPaused && (
        <VirtualControls
          onMove={setTouchMoveVector}
          onAimShoot={setTouchAimVector}
        />
      )}

      {/* 4. Paused Screen Overlay */}
      {gameState === 'playing' && isPaused && (
        <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-30 animate-fade-in">
          <div className="bg-slate-900 border border-amber-500/50 p-8 rounded-2xl shadow-2xl text-center max-w-sm w-full mx-4">
            <h3 className="text-3xl font-black text-amber-400 tracking-tighter uppercase mb-2">Game Paused</h3>
            <p className="text-xs text-slate-400 mb-6 font-mono">Demonic forces await your return.</p>
            <button
              onClick={handleTogglePause}
              className="w-full py-3.5 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white font-black rounded-xl tracking-wider uppercase transition shadow-lg cursor-pointer"
            >
              Resume Battle
            </button>
            <button
              onClick={() => setGameState('menu')}
              className="w-full mt-3 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs uppercase transition cursor-pointer"
            >
              Quit to Menu
            </button>
          </div>
        </div>
      )}

      {/* 5. Start Main Menu */}
      {gameState === 'menu' && (
        <StartMenu
          stats={stats}
          playerName={playerName}
          onChangePlayerName={handleNameChange}
          selectedSkinId={selectedSkinId}
          selectedSkillId={selectedSkillId}
          onOpenSkins={() => setModalState('skins')}
          onOpenSkills={() => setModalState('skills')}
          onOpenLeaderboard={() => setModalState('leaderboard')}
          onStart={handleStartGame}
        />
      )}

      {/* 6. Game Over Screen */}
      {gameState === 'gameover' && (
        <GameOverModal
          stats={stats}
          isNewHighScore={isNewHighScore}
          onRestart={handleStartGame}
          onMenu={() => setGameState('menu')}
          onLeaderboard={() => setModalState('leaderboard')}
        />
      )}

      {/* 7. Armory & Ranking Modals */}
      {modalState === 'skins' && (
        <SkinsModal
          currentScore={stats.highScore}
          selectedSkinId={selectedSkinId}
          onSelectSkin={(id) => {
            setSelectedSkinId(id);
            localStorage.setItem('dbs_skinId', id);
          }}
          onClose={() => setModalState('none')}
        />
      )}

      {modalState === 'skills' && (
        <SkillsModal
          selectedSkillId={selectedSkillId}
          onSelectSkill={(id) => {
            setSelectedSkillId(id);
            localStorage.setItem('dbs_skillId', id);
          }}
          onClose={() => setModalState('none')}
        />
      )}

      {modalState === 'leaderboard' && (
        <LeaderboardModal
          stats={stats}
          playerName={playerName}
          selectedSkinId={selectedSkinId}
          onClose={() => setModalState('none')}
        />
      )}
    </main>
  );
}

