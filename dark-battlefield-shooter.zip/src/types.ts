export type GameState = 'menu' | 'playing' | 'gameover' | 'paused';

export interface Position {
  x: number;
  y: number;
}

export interface Player {
  x: number;
  y: number;
  radius: number;
  angle: number; // facing angle in radians
  health: number;
  maxHealth: number;
  speed: number;
  skinId: string;
  skillId: SkillType;
  skillCooldownTimer: number;
  skillActiveTimer: number;
  activePowerUps: {
    rapidFireTimer: number; // seconds remaining
    shieldTimer: number;    // seconds remaining
  };
}

export interface Turret {
  id: string;
  x: number;
  y: number;
  radius: number;
  life: number;
  shootCooldown: number;
  color: string;
}

export type EnemyType = 'soldier' | 'heavy_soldier' | 'demon' | 'fast_demon' | 'boss_demon';

export interface Enemy {
  id: string;
  type: EnemyType;
  x: number;
  y: number;
  radius: number;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  scoreValue: number;
  color: string;
  angle: number;
  hitFlash: number;
}

export interface Bullet {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  isPlayer: boolean;
  color: string;
  trail: Position[];
}

export type PowerUpType = 'rapid_fire' | 'shield' | 'bomb' | 'health';

export interface PowerUp {
  id: string;
  x: number;
  y: number;
  radius: number;
  type: PowerUpType;
  spawnTime: number;
  pulseAngle: number;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  decay: number;
  isSpark?: boolean;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  vy: number;
  life: number;
  maxLife: number;
}

export interface BackgroundCrater {
  x: number;
  y: number;
  radius: number;
  alpha: number;
}

export interface BackgroundFlame {
  x: number;
  y: number;
  size: number;
  offset: number;
  speed: number;
}

export interface GameStats {
  score: number;
  kills: number;
  wave: number;
  highScore: number;
  highKills: number;
}

export interface WarriorSkin {
  id: string;
  name: string;
  description: string;
  armorColor: string;
  glowColor: string;
  bulletColor: string;
  unlockScore: number;
  healthMult: number;
  speedMult: number;
  dmgMult: number;
}

export type SkillType = 'dash' | 'turret' | 'nova' | 'vampire';

export interface CombatSkill {
  id: SkillType;
  name: string;
  description: string;
  cooldown: number; // seconds
  duration?: number; // seconds
  color: string;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  score: number;
  kills: number;
  wave: number;
  skinId: string;
  isPlayer?: boolean;
}

export interface RankTier {
  tier: string;
  name: string;
  minScore: number;
  color: string;
  badge: string;
}

